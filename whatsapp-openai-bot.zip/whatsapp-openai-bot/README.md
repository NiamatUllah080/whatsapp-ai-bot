# WhatsApp to OpenAI Chatbot

This is a simple Express.js server that connects WhatsApp Webhook with OpenAI's ChatGPT API.

## Setup
1. Add your OpenAI API key to a `.env` file.
2. Deploy to Railway, Render or similar.
3. Set your webhook URL in WhatsApp Business settings.

Enjoy!
